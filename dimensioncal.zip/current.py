from electrostatic import *
def Energydensity():
    print("Joule/meter^3")
    print("ML^-1T^-2")
def Electromotiveforce():
    Electricpotential()
def Electricalresistance():
    print("ohm or volt*ampere^-1")
    print("ML^2I^-2T^-3")
def Resistivity():
    print("ohm*meter or volt*(amp^-1)*meter")
    print("ML^3I^-2T^-3")
def Specificresistance():
    Resistivity()
def Conductance():
    print("mho or ohm^-1 or siemns")
    print("M^-1I^2L^-3T^3")
def Coefficientofresistance():
    print("Kelvin^-1 or degree centegrade^-1")
    print("K^-1")
def Currentdensity():
    print("Ampere/meter^2")
    print("IL^-2")
def Mobilityofelectron():
    print("(meter^2)*(volt^-1)*(second^-1)")
    print("ML^4I^-1T^-4")
def Electricwork():
    print("joule or volt*coulomb")
    print("ML^2T^-2")
def Electricpower():
    print("joule/second or watt")
    print("ML^2T^-3")
def Electricenergy():
    Electricwork()