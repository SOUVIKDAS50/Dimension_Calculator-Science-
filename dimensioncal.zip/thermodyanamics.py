def Entropy():
    print("Joule/kelvin")
    print("ML^2T^-2K^-1")
def Enthalpy():
    print("joule")
    print("ML^2T^-2")