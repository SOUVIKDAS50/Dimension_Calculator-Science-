def Angularwavenumber():
    print("meter^-1")
    print("L^-1")
def Focallength():
    print("meter")
    print("L")
def Radiousofcurvature():
    Focallength()
def Reflectingpower():
    print("meter^-1")
    print("L^-1")
def Opticalpower():
    print("meter^-1")
    print("L^-1")
def Magnification():
    print("Unitless")
    print("Dimensionless")
def Refractiveindex():
    Magnification()
def Lateraldisplacement():
    print("meter")
    print("L")
def Criticalangle():
    print("Radian")
    print("Dimentionless")
def Deviation():
    Criticalangle()
def Dispersivepower():
    Magnification()
def Angulardispersion():
    Magnification()
def Angularmagnification():
    Magnification()