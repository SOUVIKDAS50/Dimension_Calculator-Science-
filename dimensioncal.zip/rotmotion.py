from lawsofmotion import *
from workenergypower import *
def Angle():
    print("radian")
    print("Dimensionless")
def Solidangle():
    print("Steridian")
    print("Dimensionless")
def Tension():
    Force()
def Impulseofforce():
    print("Newton*second or (kelogram*meter)/second")
    print("MLT^-1")
def Momentum():
    print("(kelogram*meter)/second")
    print("MLT^-1")
def Angularmomentum():
    print("(kelogram*meter^2)/second")
    print("ML^2T^-1")
def Rateofmass():
    print("kelogram/second")
    print("MT^-1")
def Coefficientoffriction():
    print("unitless")
    print("dimensionless")
def Angulardisplacement():
    print("radian")
    print("Dimensionless")
def Angularvelocity():
    print("radian/second or second^-1")
    print("T^-1")
def Angularaccelaration():
    print("radian/second^2  or second^-2")
    print("T^-2")
def Potentialenergy():
    Energy()
def Kineticenergy():
    Energy()
def Momentofforce():
    print("Newton*meter")
    print("ML^2T^-2")
def Torque():
    Momentofforce()