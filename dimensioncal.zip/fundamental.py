def Length():
    print("meter")
    print("L")
def Displacement():
    print("meter")
    print("L")
def Mass():
    print("kelogram")
    print("M")
def Time():
    print("second")
    print("T")
def Electriccurrent():
    print("Ampere")
    print("I")
def Temperature():
    print("Kelvin")
    print("K")
def Amountofsubstances():
    print("mole")
    print("N")
def Intensity():
    print("candela")
    print("C")