def Force():
    print("Kelogram*meter)/second^2"+"or"+"Newton")
    print("MLT^-2")
    
def Pressure():
    print("kg/(meter*sec^2) or (newton/meter^2)")
    print("ML^-1T^-2")