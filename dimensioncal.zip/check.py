from fundamental import *       #class XI
from kinematics import *        #class XI
from lawsofmotion import *      #class XI
from workenergypower import *   #class XI
from rotmotion import *         #class XI
from gravity import *           #class XI
from bulkmatter import *        #class XI
from thermodyanamics import *   #class XI
from wave11 import *              #class XI
from electrostatic import *     #class XII
from current import *           #class XII
from magnetic import *          #class XII
from optics import *            #class XII
from modern import *            #class XII
Groupvelocity()
Kineticenergy()
Velocitygradient()
Gravitationalfieldintensity()








