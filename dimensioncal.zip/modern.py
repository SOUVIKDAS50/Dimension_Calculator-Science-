from current import *
def Restmass():
    print("kelogram")
    print("M")
def Workfunction():
    Electricwork()
def Stoppingpotential():
    print("volt or joule/coulomb")
    print("ML^2I^-1T^-3")
def plankconstant():
    print("joule*second or (volt*coulomb*second)")
    print("ML^2T^-1")
def Rydbergconstant():
    print("meter^-1")
    print("L^-1")
def Ionisationpotential():
    Electricwork()
def Radioactivedecay():
    print("Mole*second^-1")
    print("NT-1")
def Radioactivedecayconstant():
    print("second^-1")
    print("T^-1")
def Halflife():
    print("Second")
    print("T")
def Meanlife():
    print("Second")
    print("T")
def radioactivity():
    print("mole*second^-1")
    print("NT^-1")
def Boltzmanconstant():
    print("Joule*kelvin^-1")
    print("ML^2T^-2K^-1")
def Voltagegain():
    print("unitless")
    print("dimensionless")
def Currentgain():
    print("unitless")
    print("dimensionless")
def Powergain():
    print("unitless")
    print("dimensionless")
def Currentamplificationfactor():
    print("unitless")
    print("dimensionless")
def Currenttransferratio():
    print("unitless")
    print("dimensionless")