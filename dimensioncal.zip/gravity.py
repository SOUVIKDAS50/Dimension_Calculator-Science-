def Gravitationalconstant():
    print("(Newton*meter^2)/kelogram^2")
    print("M^-1L^3T^-2")
def Gravitationalfieldintensity():
    print("Newton/kelogram or meter/second^2")
    print("LT^-2")
def Gravitationalpotential():
    print("(Newton*meter/kelogram)")
    print("L^2T^-2")

def Gravitationalaccelaration():
    Gravitationalfieldintensity()