def Magneticfieldintensity():
    print("weber/meter^2")
    print("MT^-2I^-1")
def Permiability():
    print("weber)*(ampere^-1)*(meter^-1) or henry*meter^-1")
    print("MLT^-2I^-2")
def Magneticintensity():
    print("Ampere*meter^-1")
    print("IL^-1")
def Lorentzforce():
    print("Newton")
    print("MLT^-2")
def Magneticdipolemoment():
    print("Ampere*meter^2")
    print("IL^2")
def Bohrmagneton():
    print("(coulomb)*(meter^2)*(second^-1)")
    print("IL^2")
def Magnetisation():
    print("ampere*meter^-1")
    print("IL^-1")
def Inducedemf():
    print("volt")
    print("ML^2I^-1T^-3")
def Selfinduction():
    print("Henry or weber*amp^-1")
    print("ML^2I^-2T^-2")
def Mutualinduction():
    Selfinduction()
def Displacementcurrent():
    print(" ampere")
    print("I")
def Energydensity():
    print("joule*meter^-3")
    print("ML^-1T^-2")