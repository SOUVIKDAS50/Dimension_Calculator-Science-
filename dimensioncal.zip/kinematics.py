def Area():
    print("meter^2")
    print("L^2")
def Volume():
    print("meter^3")
    print("L^3")

def Density():
    print("kelogram/meter^3")
    print("ML^-3")

def Velocity():
    print("meter/second")
    print("LT^-1")

def Speed():
     print("meter/second")
     print("LT^-1")

def Accelaration():
    print("meter/second^2")
    print("LT^-2")

def Retardation():
     print("meter/second^2")
     print("LT^-2")

def Jerk():
    print("meter/second^3")
    print("LT^-3")

