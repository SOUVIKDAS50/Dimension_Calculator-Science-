def Stress():
    print("kg/(meter*sec^2) or (newton/meter^2)")
    print("ML^-1T^-2")
def Strain():
    print("unitless")
    print("Dimensionalless")
def Modulousofelasticity():
    Stress()
def Youngmodulous():
    Modulousofelasticity()
    
def Bulkmodulous():
    Modulousofelasticity()
def Compressibility():
    print("meter^2/newton")
    print("M^-1LT^2")
def Forceconstant():
    print("Newton/meter")
    print("MT^-2")
def Relativedensity():
    print("unitless")
    print("Dimensionalless")
def Buoyantforce():
    print("Newton")
    print("MLT^-2")
def Weight():
    print("Newton")
    print("MLT^-2")
def Coefficientofviscosity():
    print("(newton*second)/meter^2")
    print("ML^-1T^-1")
def Surfacetension():
    print("Newton/meter")
    print("MT^-2")
def Surfaceenergy():
    print("Joule")
    print("ML^2T^-2")
def Surfacedensityofenergy():
    print("Joule/meter^2")
    print("MT^-2")
def Coefficientoflinearexpansion():
    print("degree centrigrade^-1 or kelvin^-1")
    print("K^-1")
def Coefficientofsurfaceexpansion():
    print("degree centrigrade^-1 or kelvin^-1")
    print("K^-1")
def Coefficientofvolumeexpansion():
    print("degree centrigrade^-1 or kelvin^-1")
    print("K^-1")
def Molargasconstant():
    print("joule/(mole*kelvin)")
    print("ML^2T^-2N^-1K^-1")
def Heat():
    print("Joule")
    print("ML^2T^-2")
def Thermalcapasity():
    print("Joule/kelvin")
    print("ML^2T^-2K^-1")
def Specificheat():
    print("Joule/(kelogram*kelvin)")
    print("L^2T^-2K^-1")
def Latentheat():
    print("Joule/kelogram")
    print("L^2T^-2")
def Criticaltemperature():
    print("degree centigrade or kelvin")
    print("K")
def Coefficientofthermalconductivity():
    print("Watt/(meter*kelvin)")
    print("MLT^-3K^-1")
def Thermalresistance():
    print("Watt/(meter^2*kelvin)")
    print("MT^-3K^-1")
def Stefansconstant():
    print("joule/kelvin^4")
    print("ML^2T^-2K^-4")
def Workdonebygas():
    print("Newton*meter")
    print("ML^2T^-2")