def Charge():
    print("coulomb or ampere*second")
    print("IT")
def Permitivity():
    print("(coulomb^2)*(newton^-1)*(meter^-2)")
    print("M^-1L^-3T^4I^2")
def Dielectricconstant():
    print("unitless")
    print("Dimensionalless")
def Linearchargedensity():
    print("coulomb*meter^-1")
    print("L^-1IT")
def Surfacechargedensity():
    print("coulomb*meter^-2")
    print("L^-2IT")
def Volumechargedensity():
    print("coulomb*meter^-3")
    print("L^-3IT")
def Electricfieldintensity():
    print("Newton*coulomb^-1 or volt*meter^-1")
    print("MLT^-3I^-1")
def Electricdipolemoment():
    print("coulomb*meter")
    print("LTI")
def Areavector():
    print("meter^2")
    print("L^2")
def Electricflux():
    print("Newton*meter^2*coulomb^-1 or volt*meter")
    print("ML^3T^-3I^-1")
def Electricpotential():
    print("Volt")
    print("ML^2T^-3I^-1")
def Electricpotentialgradient():
    print("volt*meter^-1 or Newton*coulomb^-1")
    print("MLT^-3I^-1")
def Electronvolt():
    print("coulomb*volt")
    print("ML^2T^-2")
def Electricalpotentialenergy():
    Electronvolt()
def Capacitance():
    print("Farad or coulomb/volt")
    print("M^-1L^-2T^4I^2")