from kinematics import *
def Ampletude():
    print("Meter")
    print("L")
def Angularfrequency():
    print("second^-2")
    print("T^-2")
def Frequency():
    print("second^-1")
    print("T^-1")
def Wavelength():
    print("meter")
    print("L")
def Angularwavenumber():
    print("meter^-1")
    print("L^-1")
def Wavenumber():
    Angularwavenumber()
def Groupvelocity():
    Velocity()
def Phasevelocity():
    Velocity()
def Velocitygradient():
    print("second^-1")
    print("T^-1")