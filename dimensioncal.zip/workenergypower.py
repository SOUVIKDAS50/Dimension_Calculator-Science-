def Work():
    print("Joule or Newton*meter or (kelogram*meter^2)/second^2")
    print("ML^2T^-2")
def Power():
    print("Watt or Joule/second or Newton*(meter/second) or (kelogram*meter^2)/second^3")
    print("ML^2T^-3")
def Energy():
    print("Joule or Newton*meter or (kelogram*meter^2)/second^2")
    print("ML^2T^-2")